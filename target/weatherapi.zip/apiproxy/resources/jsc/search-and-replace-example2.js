function testFunction2(){
	'use strict';
	var test2 = "VALUE TO BE REPLACED #2";
	return test2;
}

testFunction2();